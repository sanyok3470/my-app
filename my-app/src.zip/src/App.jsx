import './App.css';
import Header from './components/header/Header.jsx';
import Banner from './components/banner/Banner.jsx';
import Cart from './components/cart/Cart.jsx';
import Footer from './components/footer/Footer.jsx';
import Overlay from './components/overlay/Overlay';
import React from 'react';
import axios from 'axios';
import { Routes, Route} from 'react-router-dom';
import Favorites from "./components/favorites/Favorites"
import Home from './components/Home';

function App() {
    //состояние корзины
    const [overlayOpen, setOverlayOpen] = React.useState(false)
    //хранение данных туров
    const [tyrs, setTyrs] = React.useState([])
    //для хранения объектов корзины
    const [overlayItems, setOverlayItems] = React.useState([])
    //Для поиска 
    const [search, setSearch ] = React.useState('')
    //Для хранения избранных заявок 
    const [favorites, setFavorites] = React.useState([])

    React.useEffect(() => {

        axios.get('https://637f91ca2f8f56e28e904e7d.mockapi.io/tyrs').then((resJson) =>{
            setTyrs(resJson.data)
        })

        axios.get('https://637f91ca2f8f56e28e904e7d.mockapi.io/cart').then((res) =>{
            setOverlayItems(res.data)
        })

        axios.get('https://637f91ca2f8f56e28e904e7d.mockapi.io/favorites').then((res) =>{
            setFavorites(res.data)
        })

    }, [])

    const deleteItems=(id)=>{
        console.log(id);
        axios.delete(`https://637f91ca2f8f56e28e904e7d.mockapi.io/cart/${id}`)
        setOverlayItems((objDelete)=> objDelete.filter(item => item.id !== id))
    }

    return (
        <div className="app">

            {overlayOpen ? 
            <Overlay
             overlayProp={overlayItems} 
            closeOverlay={() => setOverlayOpen(false)} 
            deleteItems={deleteItems}
            />
                : null
            }

           

            <Header openOverlay={() => setOverlayOpen(true)} />
            <Routes>
                <Route path='/favorites'
                    element={
                        <Favorites
                        favorites ={favorites}
                        setFavorites={setFavorites}
                        item={tyrs}
                        overlayItems={overlayItems}
                        setOverlayItems={setOverlayItems}
                        />
                    }
                />

                <Route path='/'
                    element={
                        <Home
                            item={tyrs}
                            overlayItems={overlayItems}
                            setOverlayItems={setOverlayItems}
                            setSearch={setSearch}
                            search={search}
                            favorites={favorites}
                            setFavorites={setFavorites}
                        />
                    }
                />

            </Routes>
            <Footer />


        </div>
    )
}
export default App